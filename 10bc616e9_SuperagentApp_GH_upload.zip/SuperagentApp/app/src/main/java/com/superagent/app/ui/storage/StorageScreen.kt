package com.superagent.app.ui.storage

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.superagent.app.storage.drive.DriveStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageScreen(viewModel: StorageViewModel = hiltViewModel()) {
    val driveStatus by viewModel.driveStatus.collectAsState()
    val driveFiles by viewModel.driveFiles.collectAsState()
    val localScripts by viewModel.localScripts.collectAsState()

    val signInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            try {
                val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).result
                account?.let { viewModel.handleSignIn(it) }
            } catch (e: Exception) { /* sign-in cancelled */ }
        }
    }

    LaunchedEffect(Unit) { viewModel.checkExistingSignIn() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Storage & Cloud Sync", fontWeight = FontWeight.Bold) },
                actions = {
                    if (driveStatus is DriveStatus.SignedIn) {
                        TextButton(onClick = { viewModel.signOut() }) { Text("Sign Out") }
                    } else {
                        Button(onClick = { signInLauncher.launch(viewModel.getSignInIntent()) }) {
                            Icon(Icons.Filled.AccountCircle, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Connect Drive")
                        }
                    }
                    IconButton(onClick = { viewModel.refreshLocalScripts() }) {
                        Icon(Icons.Filled.Refresh, "Refresh")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            DriveStatusCard(driveStatus)

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (localScripts.isEmpty() && driveFiles.isEmpty()) {
                    item {
                        Box(Modifier.fillParentMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.FolderOpen, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                                Spacer(Modifier.height(12.dp))
                                Text("No files yet", style = MaterialTheme.typography.titleSmall)
                                Text("Generate build scripts in the Compiler tab", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            }
                        }
                    }
                }

                if (localScripts.isNotEmpty()) {
                    item {
                        Text("Local Build Scripts (${localScripts.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                    items(localScripts, key = { it.absolutePath }) { file ->
                        LocalFileCard(
                            fileName = file.name,
                            fileSize = file.length(),
                            onUpload = { viewModel.uploadFile(file) }
                        )
                    }
                }

                if (driveFiles.isNotEmpty()) {
                    item {
                        Spacer(Modifier.height(8.dp))
                        Text("Google Drive — Superagent Folder (${driveFiles.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                    items(driveFiles, key = { it.id ?: it.name ?: "" }) { driveFile ->
                        DriveFileCard(
                            name = driveFile.name ?: "Unknown",
                            sizeBytes = driveFile.getSize()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DriveStatusCard(status: DriveStatus) {
    val (icon, text, color) = when (status) {
        is DriveStatus.SignedOut -> Triple(Icons.Filled.CloudOff, "Not connected to Google Drive", Color(0xFF9E9E9E))
        is DriveStatus.SignedIn -> Triple(Icons.Filled.Cloud, "Connected: ${status.email}", Color(0xFF4CAF50))
        is DriveStatus.Uploading -> Triple(Icons.Filled.CloudUpload, "Uploading: ${status.fileName}…", Color(0xFF42A5F5))
        is DriveStatus.Uploaded -> Triple(Icons.Filled.CloudDone, "✓ Uploaded: ${status.fileName}", Color(0xFF4CAF50))
        is DriveStatus.Error -> Triple(Icons.Filled.CloudOff, "Error: ${status.message}", Color(0xFFEF5350))
    }
    Surface(color = color.copy(alpha = 0.10f)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Text(text, fontSize = 13.sp, color = color)
        }
    }
}

@Composable
fun LocalFileCard(fileName: String, fileSize: Long, onUpload: () -> Unit) {
    Card(shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Description, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(fileName, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(
                    formatBytes(fileSize),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
            IconButton(onClick = onUpload) {
                Icon(Icons.Filled.CloudUpload, "Upload to Drive", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun DriveFileCard(name: String, sizeBytes: Long?) {
    Card(shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CloudDone, null, tint = Color(0xFF4CAF50))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                if (sizeBytes != null && sizeBytes > 0) {
                    Text(formatBytes(sizeBytes), fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            }
            Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF4CAF50), modifier = Modifier.size(18.dp))
        }
    }
}

// Drive API File.getSize() returns BigDecimal/Long — handle both
private fun com.google.api.services.drive.model.File.getSize(): Long? =
    try { this.size } catch (_: Exception) { null }

private fun formatBytes(bytes: Long): String = when {
    bytes <= 0L -> "0 B"
    bytes < 1_024L -> "$bytes B"
    bytes < 1_048_576L -> "${bytes / 1_024} KB"
    else -> "${bytes / 1_048_576} MB"
}
