package com.superagent.app.compiler.builder

import android.content.Context
import com.superagent.app.compiler.adb.AdbOrchestrator
import com.superagent.app.compiler.adb.AdbResult
import com.superagent.app.compiler.script.BuildConfig
import com.superagent.app.compiler.script.BuildScriptGenerator
import com.superagent.app.compiler.script.GeneratedScript
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

sealed class CompilerStatus {
    object Idle : CompilerStatus()
    data class Generating(val step: String) : CompilerStatus()
    data class Generated(val script: GeneratedScript) : CompilerStatus()
    data class AdbRunning(val command: String) : CompilerStatus()
    data class AdbResult(val result: com.superagent.app.compiler.adb.AdbResult) : CompilerStatus()
    data class Error(val message: String) : CompilerStatus()
}

class CompilerOrchestrator(private val context: Context) {

    private val scriptGenerator = BuildScriptGenerator(context)
    val adbOrchestrator = AdbOrchestrator()

    private val _status = MutableStateFlow<CompilerStatus>(CompilerStatus.Idle)
    val status: StateFlow<CompilerStatus> = _status.asStateFlow()

    private val _scriptHistory = MutableStateFlow<List<GeneratedScript>>(emptyList())
    val scriptHistory: StateFlow<List<GeneratedScript>> = _scriptHistory.asStateFlow()

    private val _adbLog = MutableStateFlow<List<AdbResult>>(emptyList())
    val adbLog: StateFlow<List<AdbResult>> = _adbLog.asStateFlow()

    suspend fun generateBuildScript(config: BuildConfig): GeneratedScript {
        _status.value = CompilerStatus.Generating("Assembling build script for ${config.projectName}…")
        return try {
            val script = scriptGenerator.generateBuildScript(config)
            _scriptHistory.value = (_scriptHistory.value + script).takeLast(50)
            _status.value = CompilerStatus.Generated(script)
            Timber.i("Script generated: ${script.scriptPath}")
            script
        } catch (e: Exception) {
            val msg = "Script generation failed: ${e.message}"
            _status.value = CompilerStatus.Error(msg)
            Timber.e(e, msg)
            throw e
        }
    }

    suspend fun runAdbCommand(rawCommand: String): AdbResult {
        _status.value = CompilerStatus.AdbRunning(rawCommand)
        val result = adbOrchestrator.executeRaw(rawCommand)
        _adbLog.value = (_adbLog.value + result).takeLast(100)
        _status.value = CompilerStatus.AdbResult(result)
        return result
    }

    suspend fun installApk(apkPath: String): AdbResult {
        _status.value = CompilerStatus.AdbRunning("install $apkPath")
        val result = adbOrchestrator.installApk(apkPath)
        _adbLog.value = (_adbLog.value + result).takeLast(100)
        _status.value = CompilerStatus.AdbResult(result)
        return result
    }

    fun listGeneratedScripts(): List<File> = scriptGenerator.listGeneratedScripts()
    fun deleteScript(path: String) = scriptGenerator.deleteScript(path)
    fun resetStatus() { _status.value = CompilerStatus.Idle }
}
