package com.superagent.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.superagent.app.agent.core.AgentRepository
import com.superagent.app.agent.profile.AgentProfile
import com.superagent.app.agent.state.AgentState
import com.superagent.app.agent.state.DirectiveResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AgentDetailViewModel @Inject constructor(
    private val repo: AgentRepository
) : ViewModel() {

    private val _profile = MutableStateFlow<AgentProfile?>(null)
    val profile: StateFlow<AgentProfile?> = _profile.asStateFlow()

    private val _agentState = MutableStateFlow<AgentState>(AgentState.Idle)
    val agentState: StateFlow<AgentState> = _agentState.asStateFlow()

    private val _resultLog = MutableStateFlow<List<DirectiveResult>>(emptyList())
    val resultLog: StateFlow<List<DirectiveResult>> = _resultLog.asStateFlow()

    private val _contextInfo = MutableStateFlow("0 entries | 0 tokens")
    val contextInfo: StateFlow<String> = _contextInfo.asStateFlow()

    /** Load agent profile and wire state machine state to our StateFlow */
    fun loadAgent(id: String) {
        // Collect profile from DB
        repo.allProfiles
            .map { list -> list.find { it.id == id } }
            .onEach { _profile.value = it }
            .launchIn(viewModelScope)

        // Wire the machine state — launch once, collect ongoing in its own coroutine
        viewModelScope.launch {
            val profile = repo.allProfiles.first().find { it.id == id } ?: return@launch
            val machine = repo.getOrCreateMachine(profile)
            // Collect machine state flow properly
            machine.state
                .onEach { state -> _agentState.value = state }
                .launchIn(viewModelScope)

            // Also collect result log from machine
            machine.resultLog
                .onEach { log -> _resultLog.value = log }
                .launchIn(viewModelScope)
        }
    }

    fun sendDirective(agentId: String, directive: String) = viewModelScope.launch {
        repo.sendDirective(agentId, directive)
        updateContextInfo(agentId)
    }

    fun updateSafetyLevel(agentId: String, level: Float) = viewModelScope.launch {
        val p = _profile.value ?: return@launch
        val updated = p.copy(safetyLevel = level)
        _profile.value = updated
        repo.updateProfile(updated)
        repo.getMachine(agentId)?.setSafetyLevel(level)
    }

    fun clearContext(agentId: String) {
        repo.getMachine(agentId)?.reset()
        updateContextInfo(agentId)
    }

    fun updateProfile(profile: AgentProfile) = viewModelScope.launch {
        _profile.value = profile
        repo.updateProfile(profile)
    }

    private fun updateContextInfo(agentId: String) {
        val machine = repo.getMachine(agentId) ?: return
        val buf = machine.contextWindow
        _contextInfo.value = "${buf.size} entries | ~${buf.totalTokens} tokens"
    }
}
