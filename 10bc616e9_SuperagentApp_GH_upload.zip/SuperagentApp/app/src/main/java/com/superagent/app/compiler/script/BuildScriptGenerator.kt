package com.superagent.app.compiler.script

import android.content.Context
import timber.log.Timber
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BuildConfig(
    val projectName: String,
    val packageName: String,
    val minSdk: Int = 26,
    val targetSdk: Int = 34,
    val versionCode: Int = 1,
    val versionName: String = "1.0.0-debug",
    val sourceDir: String = "src",
    val outputDir: String = "build/outputs",
    val additionalAapt2Args: String = "",
    val additionalD8Args: String = ""
)

data class GeneratedScript(
    val scriptPath: String,
    val readmePath: String,
    val config: BuildConfig,
    val generatedAt: Long = System.currentTimeMillis()
)

class BuildScriptGenerator(private val context: Context) {

    private val scriptsDir: File get() = File(context.getExternalFilesDir(null), "superagent/build_scripts").also { it.mkdirs() }

    fun generateBuildScript(config: BuildConfig): GeneratedScript {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val scriptName = "${config.projectName}_build_$timestamp.sh"
        val scriptFile = File(scriptsDir, scriptName)
        val readmeFile = File(scriptsDir, "${config.projectName}_README_$timestamp.txt")

        val scriptContent = buildScript(config)
        val readmeContent = buildReadme(config, scriptFile.absolutePath)

        scriptFile.writeText(scriptContent)
        scriptFile.setExecutable(true)
        readmeFile.writeText(readmeContent)

        Timber.i("Build script generated: ${scriptFile.absolutePath}")
        return GeneratedScript(
            scriptPath = scriptFile.absolutePath,
            readmePath = readmeFile.absolutePath,
            config = config
        )
    }

    private fun buildScript(cfg: BuildConfig): String = """
#!/usr/bin/env bash
# ============================================================
# Superagent On-Device Build Script
# Project   : ${cfg.projectName}
# Package   : ${cfg.packageName}
# Generated : ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}
# ============================================================
# REQUIREMENTS:
#   - Android SDK installed (run from Termux or a connected PC)
#   - ANDROID_HOME or ANDROID_SDK_ROOT must be set
#   - Place this script in your project root directory
# ============================================================

set -euo pipefail

PROJECT_NAME="${cfg.projectName}"
PACKAGE_NAME="${cfg.packageName}"
MIN_SDK=${cfg.minSdk}
TARGET_SDK=${cfg.targetSdk}
VERSION_CODE=${cfg.versionCode}
VERSION_NAME="${cfg.versionName}"

# ── SDK paths ──────────────────────────────────────────────
SDK_ROOT="${"\${ANDROID_HOME:-\${ANDROID_SDK_ROOT:-\$HOME/android-sdk}}"}}"
BUILD_TOOLS_VERSION=$(ls "${'$'}SDK_ROOT/build-tools/" | sort -V | tail -1)
BUILD_TOOLS="${'$'}SDK_ROOT/build-tools/${'$'}BUILD_TOOLS_VERSION"
PLATFORM_JAR="${'$'}SDK_ROOT/platforms/android-${cfg.targetSdk}/android.jar"

AAPT2="${'$'}BUILD_TOOLS/aapt2"
D8="${'$'}BUILD_TOOLS/d8"
ZIPALIGN="${'$'}BUILD_TOOLS/zipalign"
APKSIGNER="${'$'}BUILD_TOOLS/apksigner"

# ── Verify toolchain ───────────────────────────────────────
for tool in "${'$'}AAPT2" "${'$'}D8" "${'$'}ZIPALIGN"; do
    if [[ ! -f "${'$'}tool" ]]; then
        echo "[ERROR] Tool not found: ${'$'}tool"
        echo "  → Install Android SDK build-tools via sdkmanager"
        exit 1
    fi
done

if [[ ! -f "${'$'}PLATFORM_JAR" ]]; then
    echo "[ERROR] Platform jar not found for SDK ${cfg.targetSdk}"
    echo "  → Run: sdkmanager \"platforms;android-${cfg.targetSdk}\""
    exit 1
fi

echo "✓ Build tools: ${'$'}BUILD_TOOLS_VERSION"
echo "✓ Platform  : android-${cfg.targetSdk}"

# ── Directory setup ────────────────────────────────────────
SRC_DIR="${cfg.sourceDir}"
OUT_DIR="${cfg.outputDir}"
RES_DIR="${'$'}SRC_DIR/main/res"
JAVA_DIR="${'$'}SRC_DIR/main/java"
ASSETS_DIR="${'$'}SRC_DIR/main/assets"
MANIFEST="${'$'}SRC_DIR/main/AndroidManifest.xml"

BUILD_GEN="${'$'}OUT_DIR/gen"
BUILD_OBJ="${'$'}OUT_DIR/obj"
BUILD_DEX="${'$'}OUT_DIR/dex"
BUILD_APK="${'$'}OUT_DIR/apk"

mkdir -p "${'$'}BUILD_GEN" "${'$'}BUILD_OBJ" "${'$'}BUILD_DEX" "${'$'}BUILD_APK"

# ── Step 1: Compile resources with AAPT2 ──────────────────
echo ""
echo "━━ [1/5] Compiling resources with AAPT2..."
"${'$'}AAPT2" compile \
    --dir "${'$'}RES_DIR" \
    -o "${'$'}BUILD_OBJ/res.zip" \
    ${cfg.additionalAapt2Args}

# ── Step 2: Link resources ─────────────────────────────────
echo "━━ [2/5] Linking resources..."
"${'$'}AAPT2" link \
    -o "${'$'}BUILD_APK/${'$'}PROJECT_NAME-unaligned.apk" \
    -I "${'$'}PLATFORM_JAR" \
    --manifest "${'$'}MANIFEST" \
    --min-sdk-version ${'$'}MIN_SDK \
    --target-sdk-version ${'$'}TARGET_SDK \
    --version-code ${'$'}VERSION_CODE \
    --version-name "${'$'}VERSION_NAME" \
    --java "${'$'}BUILD_GEN" \
    "${'$'}BUILD_OBJ/res.zip" \
    ${ if (cfg.additionalAapt2Args.isNotEmpty()) cfg.additionalAapt2Args else "" }

# ── Step 3: Compile Java/Kotlin sources ────────────────────
echo "━━ [3/5] Compiling Java sources..."
JAVA_SOURCES=$(find "${'$'}JAVA_DIR" "${'$'}BUILD_GEN" -name "*.java" 2>/dev/null | tr '\n' ' ')
if [[ -n "${'$'}JAVA_SOURCES" ]]; then
    javac \
        -source 17 -target 17 \
        -classpath "${'$'}PLATFORM_JAR" \
        -d "${'$'}BUILD_OBJ" \
        ${'$'}JAVA_SOURCES
else
    echo "  [WARN] No .java sources found in ${'$'}JAVA_DIR"
fi

# ── Step 4: Convert to DEX with D8 ────────────────────────
echo "━━ [4/5] Converting to DEX with D8..."
CLASS_FILES=$(find "${'$'}BUILD_OBJ" -name "*.class" 2>/dev/null | tr '\n' ' ')
if [[ -n "${'$'}CLASS_FILES" ]]; then
    "${'$'}D8" \
        --output "${'$'}BUILD_DEX" \
        --min-api ${'$'}MIN_SDK \
        ${cfg.additionalD8Args} \
        ${'$'}CLASS_FILES
else
    echo "  [WARN] No .class files found — skipping DEX step"
fi

# ── Step 5: Package APK & zipalign ────────────────────────
echo "━━ [5/5] Packaging debug APK..."

# Add DEX to APK
if [[ -f "${'$'}BUILD_DEX/classes.dex" ]]; then
    cd "${'$'}BUILD_DEX" && zip -u "${'$'}BUILD_APK/${'$'}PROJECT_NAME-unaligned.apk" classes.dex && cd -
fi

# Add assets if present
if [[ -d "${'$'}ASSETS_DIR" ]]; then
    cd "${'$'}ASSETS_DIR" && zip -r "${'$'}BUILD_APK/${'$'}PROJECT_NAME-unaligned.apk" . && cd -
fi

# Zipalign
"${'$'}ZIPALIGN" -v -p 4 \
    "${'$'}BUILD_APK/${'$'}PROJECT_NAME-unaligned.apk" \
    "${'$'}BUILD_APK/${'$'}PROJECT_NAME-debug.apk"

# ── Debug sign with apksigner ──────────────────────────────
if command -v keytool &>/dev/null && [[ -f "${'$'}HOME/.android/debug.keystore" ]]; then
    echo "  → Signing with debug keystore..."
    "${'$'}APKSIGNER" sign \
        --ks "${'$'}HOME/.android/debug.keystore" \
        --ks-pass pass:android \
        --key-pass pass:android \
        "${'$'}BUILD_APK/${'$'}PROJECT_NAME-debug.apk"
    echo "  ✓ Signed"
else
    echo "  [WARN] debug.keystore not found — APK unsigned"
fi

echo ""
echo "════════════════════════════════════════════"
echo "✓ BUILD COMPLETE"
echo "  Output: ${'$'}BUILD_APK/${'$'}PROJECT_NAME-debug.apk"
echo "════════════════════════════════════════════"

# ── Optional: ADB install ──────────────────────────────────
if command -v adb &>/dev/null; then
    read -rp "Install on connected device? [y/N] " choice
    if [[ "${'$'}choice" == "y" || "${'$'}choice" == "Y" ]]; then
        adb install -r "${'$'}BUILD_APK/${'$'}PROJECT_NAME-debug.apk"
        echo "✓ Installed via ADB"
    fi
fi
""".trimIndent()

    private fun buildReadme(cfg: BuildConfig, scriptPath: String): String = """
SUPERAGENT BUILD SCRIPT — README
=================================
Project : ${cfg.projectName}
Package : ${cfg.packageName}
Script  : $scriptPath
Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}

HOW TO RUN THIS SCRIPT
───────────────────────
OPTION A — Termux (on-device, no PC needed):
  1. Install Termux from F-Droid
  2. pkg install openjdk-17 android-tools
  3. Set ANDROID_HOME: export ANDROID_HOME=$HOME/android-sdk
  4. Install SDK tools: sdkmanager "build-tools;34.0.0" "platforms;android-34"
  5. Copy this script to your project root
  6. chmod +x ${cfg.projectName}_build.sh && ./${cfg.projectName}_build.sh

OPTION B — PC (Linux/macOS):
  1. Ensure Android SDK is installed and ANDROID_HOME is set
  2. chmod +x ${cfg.projectName}_build.sh
  3. ./${cfg.projectName}_build.sh

OPTION C — PC (Windows PowerShell):
  Adapt paths and run the equivalent adb / aapt2 / d8 commands manually.

WHAT THIS SCRIPT DOES
───────────────────────
1. Compiles your resources with AAPT2
2. Links resources and generates R.java
3. Compiles Java/Kotlin sources with javac
4. Converts class files to DEX with D8
5. Packages everything into a debug APK
6. Optionally installs via ADB

OUTPUT
───────
${cfg.outputDir}/apk/${cfg.projectName}-debug.apk

Need help? Open the Superagent app → Compiler tab.
""".trimIndent()

    fun listGeneratedScripts(): List<File> =
        scriptsDir.listFiles { f -> f.extension == "sh" }?.toList()?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun deleteScript(path: String): Boolean = File(path).delete()
}
