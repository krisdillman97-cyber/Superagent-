package com.superagent.app.ui.theme

import android.content.Context
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

// ─── DataStore extension (single instance per process) ───────────────────────
val Context.themeDataStore by preferencesDataStore(name = "superagent_theme")

// ─── Config model ─────────────────────────────────────────────────────────────
data class ThemeConfig(
    val isDarkMode: Boolean = true,
    val primaryColorArgb: Long = 0xFF6200EE,
    val secondaryColorArgb: Long = 0xFF03DAC6,
    val density: Float = 1.0f,
    val componentScale: Float = 1.0f,
    val fontScale: Float = 1.0f,
    val cornerRadius: Float = 12f
)

// ─── DataStore keys ───────────────────────────────────────────────────────────
private object ThemeKeys {
    val DARK_MODE       = booleanPreferencesKey("dark_mode")
    val PRIMARY_COLOR   = longPreferencesKey("primary_color")
    val SECONDARY_COLOR = longPreferencesKey("secondary_color")
    val DENSITY         = floatPreferencesKey("density")
    val COMP_SCALE      = floatPreferencesKey("component_scale")
    val FONT_SCALE      = floatPreferencesKey("font_scale")
    val CORNER_RADIUS   = floatPreferencesKey("corner_radius")
}

// ─── Repository ───────────────────────────────────────────────────────────────
class ThemeRepository(private val context: Context) {

    val themeConfig: Flow<ThemeConfig> = context.themeDataStore.data.map { p ->
        ThemeConfig(
            isDarkMode          = p[ThemeKeys.DARK_MODE]       ?: true,
            primaryColorArgb    = p[ThemeKeys.PRIMARY_COLOR]   ?: 0xFF6200EE,
            secondaryColorArgb  = p[ThemeKeys.SECONDARY_COLOR] ?: 0xFF03DAC6,
            density             = p[ThemeKeys.DENSITY]         ?: 1.0f,
            componentScale      = p[ThemeKeys.COMP_SCALE]      ?: 1.0f,
            fontScale           = p[ThemeKeys.FONT_SCALE]      ?: 1.0f,
            cornerRadius        = p[ThemeKeys.CORNER_RADIUS]   ?: 12f
        )
    }

    suspend fun saveConfig(config: ThemeConfig) {
        context.themeDataStore.edit { p ->
            p[ThemeKeys.DARK_MODE]       = config.isDarkMode
            p[ThemeKeys.PRIMARY_COLOR]   = config.primaryColorArgb
            p[ThemeKeys.SECONDARY_COLOR] = config.secondaryColorArgb
            p[ThemeKeys.DENSITY]         = config.density
            p[ThemeKeys.COMP_SCALE]      = config.componentScale
            p[ThemeKeys.FONT_SCALE]      = config.fontScale
            p[ThemeKeys.CORNER_RADIUS]   = config.cornerRadius
        }
    }
}

// ─── ViewModel ────────────────────────────────────────────────────────────────
@HiltViewModel
class ThemeViewModel @Inject constructor(
    private val repo: ThemeRepository
) : ViewModel() {

    val themeConfig: StateFlow<ThemeConfig> = repo.themeConfig
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeConfig())

    fun updateConfig(config: ThemeConfig) = viewModelScope.launch { repo.saveConfig(config) }
    fun toggleDark() = viewModelScope.launch { repo.saveConfig(themeConfig.value.copy(isDarkMode = !themeConfig.value.isDarkMode)) }
    fun setPrimaryColor(argb: Long) = viewModelScope.launch { repo.saveConfig(themeConfig.value.copy(primaryColorArgb = argb)) }
    fun setDensity(d: Float) = viewModelScope.launch { repo.saveConfig(themeConfig.value.copy(density = d)) }
    fun setFontScale(s: Float) = viewModelScope.launch { repo.saveConfig(themeConfig.value.copy(fontScale = s)) }
    fun setCornerRadius(r: Float) = viewModelScope.launch { repo.saveConfig(themeConfig.value.copy(cornerRadius = r)) }
}

// ─── Composable theme ─────────────────────────────────────────────────────────
@Composable
fun SuperagentThemeEngine(config: ThemeConfig, content: @Composable () -> Unit) {
    val primary   = Color(config.primaryColorArgb)
    val secondary = Color(config.secondaryColorArgb)

    val colorScheme = if (config.isDarkMode) {
        darkColorScheme(
            primary       = primary,
            secondary     = secondary,
            tertiary      = primary.copy(alpha = 0.7f),
            background    = Color(0xFF0D0D0D),
            surface       = Color(0xFF1A1A2E),
            surfaceVariant = Color(0xFF16213E),
            onPrimary     = Color.White,
            onBackground  = Color.White,
            onSurface     = Color.White
        )
    } else {
        lightColorScheme(
            primary   = primary,
            secondary = secondary,
            tertiary  = primary.copy(alpha = 0.7f)
        )
    }

    MaterialTheme(colorScheme = colorScheme, content = content)
}

// ─── Color presets ────────────────────────────────────────────────────────────
data class ColorPreset(val name: String, val primary: Long, val secondary: Long)

val COLOR_PRESETS = listOf(
    ColorPreset("Cyber Purple", 0xFF6200EEL, 0xFF03DAC6L),
    ColorPreset("Neon Green",   0xFF00E676L, 0xFF1DE9B6L),
    ColorPreset("Steel Blue",   0xFF1565C0L, 0xFF42A5F5L),
    ColorPreset("Crimson",      0xFFD32F2FL, 0xFFFF7043L),
    ColorPreset("Solar Gold",   0xFFF9A825L, 0xFFFFCA28L),
    ColorPreset("Deep Space",   0xFF263238L, 0xFF546E7AL),
    ColorPreset("Matrix",       0xFF00C853L, 0xFF69F0AEL),
    ColorPreset("Plasma Pink",  0xFFE91E63L, 0xFFFF4081L)
)
