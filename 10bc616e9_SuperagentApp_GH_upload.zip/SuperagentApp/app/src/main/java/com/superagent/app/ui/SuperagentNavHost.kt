package com.superagent.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.superagent.app.ui.compiler.CompilerScreen
import com.superagent.app.ui.dashboard.AgentDetailScreen
import com.superagent.app.ui.dashboard.DashboardScreen
import com.superagent.app.ui.settings.SettingsScreen
import com.superagent.app.ui.storage.StorageScreen

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Agents", Icons.Filled.SmartToy)
    object Compiler  : Screen("compiler",  "Compiler", Icons.Filled.Code)
    object Storage   : Screen("storage",   "Storage", Icons.Filled.FolderOpen)
    object Settings  : Screen("settings",  "Settings", Icons.Filled.Tune)
}

private val bottomNavItems = listOf(
    Screen.Dashboard,
    Screen.Compiler,
    Screen.Storage,
    Screen.Settings
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuperagentNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDest = navBackStackEntry?.destination
                bottomNavItems.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        selected = currentDest?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(onAgentClick = { id -> navController.navigate("agent_detail/$id") })
            }
            composable("agent_detail/{agentId}") { back ->
                val id = back.arguments?.getString("agentId") ?: return@composable
                AgentDetailScreen(agentId = id, onBack = { navController.popBackStack() })
            }
            composable(Screen.Compiler.route) { CompilerScreen() }
            composable(Screen.Storage.route)  { StorageScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}
