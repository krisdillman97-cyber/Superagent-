package com.superagent.app.ui.dashboard

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.superagent.app.agent.core.AgentRepository
import com.superagent.app.agent.profile.AgentProfile
import com.superagent.app.ui.overlay.FloatingHudService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val agentRepo: AgentRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val profiles = agentRepo.allProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProfile = agentRepo.activeProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun createProfile(name: String, instructions: String) = viewModelScope.launch {
        val profile = AgentProfile(name = name, systemInstructions = instructions)
        agentRepo.createProfile(profile)
    }

    fun activateProfile(id: String) = viewModelScope.launch {
        agentRepo.activateProfile(id)
    }

    fun deactivateAll() = viewModelScope.launch {
        // Directly call DAO deactivateAll via repository
        agentRepo.deactivateAll()
    }

    fun cloneProfile(profile: AgentProfile) = viewModelScope.launch {
        agentRepo.cloneProfile(profile)
    }

    fun deleteProfile(profile: AgentProfile) = viewModelScope.launch {
        agentRepo.deleteProfile(profile)
    }

    fun toggleOverlay(start: Boolean) {
        val intent = Intent(context, FloatingHudService::class.java)
        if (start) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } else {
            intent.action = FloatingHudService.ACTION_STOP
            context.startService(intent)
        }
    }
}
