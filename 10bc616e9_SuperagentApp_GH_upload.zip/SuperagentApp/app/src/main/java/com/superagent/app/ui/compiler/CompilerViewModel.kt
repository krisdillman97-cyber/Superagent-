package com.superagent.app.ui.compiler

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.superagent.app.compiler.adb.AdbResult
import com.superagent.app.compiler.builder.CompilerOrchestrator
import com.superagent.app.compiler.builder.CompilerStatus
import com.superagent.app.compiler.script.BuildConfig
import com.superagent.app.compiler.script.GeneratedScript
import com.superagent.app.storage.drive.DriveRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

@HiltViewModel
class CompilerViewModel @Inject constructor(
    private val orchestrator: CompilerOrchestrator,
    private val driveRepo: DriveRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val status: StateFlow<CompilerStatus> = orchestrator.status
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CompilerStatus.Idle)

    val scriptHistory: StateFlow<List<GeneratedScript>> = orchestrator.scriptHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adbLog: StateFlow<List<AdbResult>> = orchestrator.adbLog
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _adbAvailable = MutableStateFlow(false)
    val adbAvailable: StateFlow<Boolean> = _adbAvailable.asStateFlow()

    init {
        viewModelScope.launch {
            _adbAvailable.value = orchestrator.adbOrchestrator.isAdbAvailable()
        }
    }

    fun generateScript(config: BuildConfig) = viewModelScope.launch {
        try { orchestrator.generateBuildScript(config) }
        catch (e: Exception) { Timber.e(e, "Script generation error") }
    }

    fun runAdbCommand(command: String) = viewModelScope.launch {
        orchestrator.runAdbCommand(command)
    }

    fun shareScript(script: GeneratedScript) {
        try {
            val file = File(script.scriptPath)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/x-sh"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Build Script").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Timber.e(e, "Share script failed")
        }
    }

    fun deleteScript(script: GeneratedScript) {
        orchestrator.deleteScript(script.scriptPath)
    }

    fun uploadToDrive(script: GeneratedScript) = viewModelScope.launch {
        driveRepo.uploadFile(File(script.scriptPath), "text/x-sh")
    }
}
