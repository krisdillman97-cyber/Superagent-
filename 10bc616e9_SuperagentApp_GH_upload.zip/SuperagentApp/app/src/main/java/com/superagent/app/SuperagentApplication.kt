package com.superagent.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class SuperagentApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return

            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_HUD,
                    "Floating HUD",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Superagent floating overlay — ongoing"
                    setShowBadge(false)
                }
            )

            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_COMPILER,
                    "Compiler Engine",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "On-device build engine progress"
                    setShowBadge(true)
                }
            )
        }
    }

    companion object {
        const val CHANNEL_HUD = "superagent_hud"
        const val CHANNEL_COMPILER = "superagent_compiler"
    }
}
