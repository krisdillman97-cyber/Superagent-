package com.superagent.app.compiler.builder

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.superagent.app.MainActivity
import com.superagent.app.R
import com.superagent.app.SuperagentApplication
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class CompilerService : Service() {

    @Inject lateinit var orchestrator: CompilerOrchestrator

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Compiler engine active"))

        val action = intent?.getStringExtra(EXTRA_ACTION) ?: return START_NOT_STICKY

        scope.launch {
            when (action) {
                ACTION_ADB -> {
                    val cmd = intent.getStringExtra(EXTRA_COMMAND) ?: return@launch
                    Timber.d("CompilerService ADB: $cmd")
                    orchestrator.runAdbCommand(cmd)
                }
                ACTION_INSTALL -> {
                    val path = intent.getStringExtra(EXTRA_APK_PATH) ?: return@launch
                    Timber.d("CompilerService install: $path")
                    orchestrator.installApk(path)
                }
                ACTION_STOP -> stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, SuperagentApplication.CHANNEL_COMPILER)
            .setContentTitle(getString(R.string.notification_compiler_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val NOTIFICATION_ID = 2
        const val EXTRA_ACTION = "action"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_APK_PATH = "apk_path"
        const val ACTION_ADB = "adb"
        const val ACTION_INSTALL = "install"
        const val ACTION_STOP = "stop"
    }
}
