package com.superagent.app.di

import android.content.Context
import androidx.room.Room
import com.superagent.app.agent.profile.AgentProfileDao
import com.superagent.app.compiler.builder.CompilerOrchestrator
import com.superagent.app.storage.drive.DriveRepository
import com.superagent.app.storage.local.SuperagentDatabase
import com.superagent.app.ui.theme.ThemeRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SuperagentDatabase =
        Room.databaseBuilder(
            context,
            SuperagentDatabase::class.java,
            "superagent.db"
        ).fallbackToDestructiveMigration().build()

    @Provides
    @Singleton
    fun provideAgentProfileDao(db: SuperagentDatabase): AgentProfileDao =
        db.agentProfileDao()

    @Provides
    @Singleton
    fun provideCompilerOrchestrator(@ApplicationContext context: Context): CompilerOrchestrator =
        CompilerOrchestrator(context)

    @Provides
    @Singleton
    fun provideDriveRepository(@ApplicationContext context: Context): DriveRepository =
        DriveRepository(context)

    @Provides
    @Singleton
    fun provideThemeRepository(@ApplicationContext context: Context): ThemeRepository =
        ThemeRepository(context)
}
