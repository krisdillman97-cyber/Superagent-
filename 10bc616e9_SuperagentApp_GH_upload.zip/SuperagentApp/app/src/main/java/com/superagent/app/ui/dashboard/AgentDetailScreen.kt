package com.superagent.app.ui.dashboard

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.superagent.app.agent.profile.AgentProfile
import com.superagent.app.agent.state.AgentState
import com.superagent.app.agent.state.DirectiveResult

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentDetailScreen(
    agentId: String,
    onBack: () -> Unit,
    viewModel: AgentDetailViewModel = hiltViewModel()
) {
    LaunchedEffect(agentId) { viewModel.loadAgent(agentId) }

    val profile     by viewModel.profile.collectAsState()
    val agentState  by viewModel.agentState.collectAsState()
    val resultLog   by viewModel.resultLog.collectAsState()
    val contextInfo by viewModel.contextInfo.collectAsState()
    var directive   by remember { mutableStateOf("") }
    var showEdit    by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(profile?.name ?: "Agent", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    IconButton(onClick = { showEdit = true }) { Icon(Icons.Filled.Edit, "Edit") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            AgentStateBanner(agentState)
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            profile?.let { p ->
                SafetySliderRow(
                    value = p.safetyLevel,
                    onValueChange = { viewModel.updateSafetyLevel(agentId, it) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            }

            // Context info bar
            Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Context: $contextInfo", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    TextButton(onClick = { viewModel.clearContext(agentId) }, contentPadding = PaddingValues(0.dp)) {
                        Text("Clear", fontSize = 11.sp)
                    }
                }
            }

            // Result log
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                reverseLayout = true
            ) {
                if (resultLog.isEmpty()) {
                    item {
                        Box(Modifier.fillParentMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.Terminal, null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                                Spacer(Modifier.height(8.dp))
                                Text("No directives yet. Type one below.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
                items(resultLog.reversed(), key = { it.id }) { result ->
                    DirectiveResultCard(result)
                }
            }

            DirectiveInputBar(
                value = directive,
                onValueChange = { directive = it },
                onSend = {
                    if (directive.isNotBlank()) {
                        viewModel.sendDirective(agentId, directive.trim())
                        directive = ""
                    }
                },
                enabled = agentState !is AgentState.Processing && agentState !is AgentState.Building
            )
        }
    }

    profile?.let { p ->
        if (showEdit) {
            EditAgentDialog(
                profile = p,
                onConfirm = { updated -> viewModel.updateProfile(updated); showEdit = false },
                onDismiss = { showEdit = false }
            )
        }
    }
}

@Composable
fun AgentStateBanner(state: AgentState) {
    val (icon, label, color) = when (state) {
        is AgentState.Idle       -> Triple(Icons.Filled.HourglassEmpty, "Idle — ready for directives", Color(0xFF9E9E9E))
        is AgentState.Processing -> Triple(Icons.Filled.Memory, "Processing: ${state.directive.take(40)}…", Color(0xFF42A5F5))
        is AgentState.Building   -> Triple(Icons.Filled.Build, "Building: ${state.target.take(40)}", Color(0xFFFFA726))
        is AgentState.Executing  -> Triple(Icons.Filled.Terminal, "Executing: ${state.command.take(40)}", Color(0xFF66BB6A))
        is AgentState.Completed  -> Triple(Icons.Filled.CheckCircle, "Completed", Color(0xFF4CAF50))
        is AgentState.Error      -> Triple(Icons.Filled.Error, "Error: ${state.message.take(50)}", Color(0xFFEF5350))
        is AgentState.Paused     -> Triple(Icons.Filled.Pause, "Paused", Color(0xFFFFEB3B))
    }
    Surface(color = color.copy(alpha = 0.12f)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, fontSize = 12.sp, color = color, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun SafetySliderRow(value: Float, onValueChange: (Float) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Safety Level", fontSize = 13.sp, fontWeight = FontWeight.Medium)
            val label = when {
                value < 0.2f -> "Unrestricted ⚠"
                value < 0.4f -> "Low"
                value < 0.6f -> "Medium"
                value < 0.8f -> "High"
                else -> "Maximum"
            }
            Text(label, fontSize = 13.sp, color = when {
                value < 0.3f -> Color(0xFFEF5350)
                value < 0.6f -> Color(0xFFFFA726)
                else -> Color(0xFF66BB6A)
            })
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..1f,
            steps = 9,
            colors = SliderDefaults.colors(
                thumbColor = when {
                    value < 0.3f -> Color(0xFFEF5350)
                    value < 0.6f -> Color(0xFFFFA726)
                    else -> Color(0xFF66BB6A)
                }
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Unrestricted", fontSize = 10.sp, color = Color(0xFFEF5350))
            Text("Maximum Safe", fontSize = 10.sp, color = Color(0xFF66BB6A))
        }
    }
}

@Composable
fun DirectiveResultCard(result: DirectiveResult) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (result.success) MaterialTheme.colorScheme.surface
            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
        )
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (result.success) Icons.Filled.ChevronRight else Icons.Filled.Warning,
                    null,
                    modifier = Modifier.size(14.dp),
                    tint = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    result.directive.take(80),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                    modifier = Modifier.weight(1f)
                )
                if (result.durationMs > 0) {
                    Text("${result.durationMs}ms", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f))
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(
                result.output,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                color = if (result.success) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error
            )
            result.artifacts.forEach { artifact ->
                Text("📎 $artifact", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

@Composable
fun DirectiveInputBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    enabled: Boolean
) {
    Surface(tonalElevation = 4.dp) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp).navigationBarsPadding(),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Enter directive…", fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
                minLines = 1,
                maxLines = 6,
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = onSend,
                enabled = enabled && value.isNotBlank()
            ) {
                Icon(Icons.Filled.Send, "Send")
            }
        }
    }
}

@Composable
fun EditAgentDialog(
    profile: AgentProfile,
    onConfirm: (AgentProfile) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(profile.name) }
    var instructions by remember { mutableStateOf(profile.systemInstructions) }
    var objective by remember { mutableStateOf(profile.objectiveSummary) }
    var target by remember { mutableStateOf(profile.compilationTarget) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Agent") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = instructions, onValueChange = { instructions = it }, label = { Text("System Instructions") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = objective, onValueChange = { objective = it }, label = { Text("Objective Summary") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = target, onValueChange = { target = it }, label = { Text("Compilation Target") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    onConfirm(profile.copy(name = name, systemInstructions = instructions, objectiveSummary = objective, compilationTarget = target))
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
