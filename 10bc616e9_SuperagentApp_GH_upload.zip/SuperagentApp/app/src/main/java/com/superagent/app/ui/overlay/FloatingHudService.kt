package com.superagent.app.ui.overlay

import android.app.*
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.util.TypedValue
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.superagent.app.MainActivity
import com.superagent.app.R
import com.superagent.app.SuperagentApplication
import com.superagent.app.agent.core.AgentRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class FloatingHudService : Service() {

    @Inject lateinit var agentRepo: AgentRepository

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var windowManager: WindowManager

    private var bubbleView: View? = null
    private var hudPanelView: View? = null
    private var isPanelExpanded = false

    // Drag state
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())

        if (Settings.canDrawOverlays(this)) {
            createBubble()
        } else {
            Timber.w("SYSTEM_ALERT_WINDOW not granted — stopping HUD")
            stopSelf()
        }
        return START_STICKY
    }

    // ── Bubble ────────────────────────────────────────────────────────────────

    private fun createBubble() {
        val size = dp(64)
        val params = overlayParams(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 300
        }

        val bubble = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#FF6200EE"))
                setStroke(dp(2), Color.parseColor("#CCBB86FC"))
            }
            elevation = 12f
        }

        val icon = TextView(this).apply {
            text = "⚡"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        bubble.addView(icon)

        bubble.setOnTouchListener(makeDragListener(params, bubble))
        bubbleView = bubble
        try { windowManager.addView(bubble, params) } catch (e: Exception) { Timber.e(e, "Bubble add failed") }
    }

    private fun makeDragListener(params: WindowManager.LayoutParams, view: View): View.OnTouchListener {
        var dragging = false
        var touchDownTime = 0L
        return View.OnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    touchDownTime = System.currentTimeMillis()
                    initialX = params.x; initialY = params.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (dx * dx + dy * dy > 64) dragging = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging && System.currentTimeMillis() - touchDownTime < 400) {
                        togglePanel(params)
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ── Panel ─────────────────────────────────────────────────────────────────

    private fun togglePanel(bubbleParams: WindowManager.LayoutParams) {
        if (isPanelExpanded) collapsePanel() else expandPanel(bubbleParams)
    }

    private fun expandPanel(bubbleParams: WindowManager.LayoutParams) {
        val pw = dp(320)
        val params = overlayParams(pw, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            gravity = Gravity.TOP or Gravity.START
            x = (bubbleParams.x - pw / 2).coerceAtLeast(8)
            y = bubbleParams.y + dp(72)
        }

        val panel = buildPanel()
        hudPanelView = panel
        try { windowManager.addView(panel, params) } catch (e: Exception) { Timber.e(e, "Panel add failed"); return }
        isPanelExpanded = true
    }

    private fun buildPanel(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#F01C1C2E"))
                setStroke(dp(1), Color.parseColor("#55BB86FC"))
            }
            elevation = 20f
        }

        // Title + close
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = "⚡ Superagent HUD"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        titleRow.addView(TextView(this).apply {
            text = "✕"; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setPadding(dp(8), 0, 0, 0)
            setOnClickListener { collapsePanel() }
        })
        root.addView(titleRow)
        root.addView(divider())

        // Safety slider
        val safetyLabel = TextView(this).apply {
            text = "Safety: 70%"
            setTextColor(Color.parseColor("#BBBBBB"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        root.addView(safetyLabel)

        root.addView(SeekBar(this).apply {
            max = 10; progress = 7
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    safetyLabel.text = "Safety: ${p * 10}%"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    val level = sb.progress / 10f
                    // Fire-and-forget: get active profile once, update machine
                    scope.launch {
                        try {
                            val profile = agentRepo.activeProfile.filterNotNull().first()
                            agentRepo.getMachine(profile.id)?.setSafetyLevel(level)
                        } catch (_: Exception) {}
                    }
                }
            })
        })

        root.addView(divider())

        // Directive input
        val inputField = EditText(this).apply {
            hint = "Quick directive…"
            setHintTextColor(Color.parseColor("#88FFFFFF"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#22FFFFFF"))
                cornerRadius = dp(8).toFloat()
            }
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8); bottomMargin = dp(6)
            }
        }
        root.addView(inputField)

        // Macro row
        val macroRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        }
        listOf("status", "build apk", "recall", "clear").forEach { macro ->
            macroRow.addView(TextView(this).apply {
                text = macro
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#336200EE"))
                    cornerRadius = dp(6).toFloat()
                    setStroke(dp(1), Color.parseColor("#44BB86FC"))
                }
                setPadding(dp(8), dp(5), dp(8), dp(5))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) }
                setOnClickListener { inputField.setText(macro) }
            })
        }
        root.addView(macroRow)

        // Send button
        root.addView(TextView(this).apply {
            text = "⚡  Send Directive"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FF6200EE"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(0, dp(12), 0, dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setOnClickListener {
                val text = inputField.text.toString().trim()
                if (text.isEmpty()) return@setOnClickListener
                scope.launch {
                    try {
                        val profile = agentRepo.activeProfile.filterNotNull().first()
                        agentRepo.sendDirective(profile.id, text)
                        withContext(Dispatchers.Main) { inputField.text.clear() }
                    } catch (e: Exception) {
                        Timber.e(e, "HUD directive failed")
                    }
                }
            }
        })

        return root
    }

    private fun collapsePanel() {
        hudPanelView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
            hudPanelView = null
        }
        isPanelExpanded = false
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onDestroy() {
        scope.cancel()
        bubbleView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        hudPanelView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun divider() = View(this).apply {
        setBackgroundColor(Color.parseColor("#33FFFFFF"))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
            topMargin = dp(8); bottomMargin = dp(8)
        }
    }

    @Suppress("DEPRECATION")
    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, SuperagentApplication.CHANNEL_HUD)
            .setContentTitle(getString(R.string.notification_hud_title))
            .setContentText(getString(R.string.notification_hud_text))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val NOTIFICATION_ID = 1
        const val ACTION_STOP = "STOP_HUD"
    }
}
