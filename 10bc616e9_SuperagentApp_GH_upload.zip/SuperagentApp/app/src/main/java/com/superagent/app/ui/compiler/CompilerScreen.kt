package com.superagent.app.ui.compiler

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.superagent.app.compiler.builder.CompilerStatus
import com.superagent.app.compiler.script.BuildConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompilerScreen(viewModel: CompilerViewModel = hiltViewModel()) {
    val status by viewModel.status.collectAsState()
    val scriptHistory by viewModel.scriptHistory.collectAsState()
    val adbLog by viewModel.adbLog.collectAsState()
    val adbAvailable by viewModel.adbAvailable.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Build Script", "ADB Console", "History")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Compiler Engine", fontWeight = FontWeight.Bold) },
                actions = {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 16.dp)) {
                        Box(Modifier.size(8.dp).background(if (adbAvailable) Color(0xFF00E676) else Color(0xFFEF5350), shape = RoundedCornerShape(4.dp)))
                        Spacer(Modifier.width(4.dp))
                        Text("ADB", fontSize = 12.sp)
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            CompilerStatusBanner(status)
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { i, tab -> Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(tab) }) }
            }
            when (selectedTab) {
                0 -> BuildScriptTab(viewModel)
                1 -> AdbConsoleTab(viewModel, adbLog)
                2 -> ScriptHistoryTab(scriptHistory, viewModel)
            }
        }
    }
}

@Composable
fun CompilerStatusBanner(status: CompilerStatus) {
    val (text, color) = when (status) {
        is CompilerStatus.Idle -> "Ready" to Color(0xFF9E9E9E)
        is CompilerStatus.Generating -> "Generating: ${status.step}" to Color(0xFF42A5F5)
        is CompilerStatus.Generated -> "Script ready: ${status.script.config.projectName}" to Color(0xFF4CAF50)
        is CompilerStatus.AdbRunning -> "ADB: ${status.command.take(50)}" to Color(0xFFFFA726)
        is CompilerStatus.AdbResult -> (if (status.result.success) "ADB OK" else "ADB Error") to (if (status.result.success) Color(0xFF4CAF50) else Color(0xFFEF5350))
        is CompilerStatus.Error -> "Error: ${status.message.take(60)}" to Color(0xFFEF5350)
    }
    Surface(color = color.copy(alpha = 0.12f)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = color)
    }
}

@Composable
fun BuildScriptTab(viewModel: CompilerViewModel) {
    var projectName by remember { mutableStateOf("MyProject") }
    var packageName by remember { mutableStateOf("com.example.myapp") }
    var minSdk by remember { mutableStateOf("26") }
    var targetSdk by remember { mutableStateOf("34") }
    var versionName by remember { mutableStateOf("1.0.0-debug") }
    var extraAapt2 by remember { mutableStateOf("") }
    var extraD8 by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Build Configuration", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = projectName, onValueChange = { projectName = it }, label = { Text("Project Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = packageName, onValueChange = { packageName = it }, label = { Text("Package Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = minSdk, onValueChange = { minSdk = it }, label = { Text("Min SDK") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = targetSdk, onValueChange = { targetSdk = it }, label = { Text("Target SDK") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(value = versionName, onValueChange = { versionName = it }, label = { Text("Version Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = extraAapt2, onValueChange = { extraAapt2 = it }, label = { Text("Extra AAPT2 Args (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = extraD8, onValueChange = { extraD8 = it }, label = { Text("Extra D8 Args (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Divider()
        Button(onClick = {
            viewModel.generateScript(BuildConfig(projectName = projectName.trim(), packageName = packageName.trim(), minSdk = minSdk.toIntOrNull() ?: 26, targetSdk = targetSdk.toIntOrNull() ?: 34, versionName = versionName.trim(), additionalAapt2Args = extraAapt2.trim(), additionalD8Args = extraD8.trim()))
        }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Build, null); Spacer(Modifier.width(8.dp)); Text("Generate Build Script")
        }
        Text("The generated .sh script runs via Termux or any machine with Android SDK. Calls: AAPT2 → javac → D8 → zipalign → apksigner.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
    }
}

@Composable
fun AdbConsoleTab(viewModel: CompilerViewModel, log: List<com.superagent.app.compiler.adb.AdbResult>) {
    var command by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp), reverseLayout = true) {
            items(log.reversed()) { AdbLogEntry(it) }
            if (log.isEmpty()) {
                item { Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { Text("ADB log empty. Run a command below.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)) } }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("adb devices", "adb shell getprop ro.product.model").forEach { macro ->
                FilterChip(selected = false, onClick = { command = macro }, label = { Text(macro.take(22), fontSize = 10.sp) })
            }
        }
        Surface(tonalElevation = 4.dp) {
            Row(Modifier.fillMaxWidth().padding(8.dp).navigationBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = command, onValueChange = { command = it }, modifier = Modifier.weight(1f), placeholder = { Text("adb devices", fontFamily = FontFamily.Monospace, fontSize = 13.sp) }, singleLine = true, )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { if (command.isNotBlank()) { viewModel.runAdbCommand(command.trim()); command = "" } }, enabled = command.isNotBlank()) { Icon(Icons.Filled.PlayArrow, "Run") }
            }
        }
    }
}

@Composable
fun AdbLogEntry(result: com.superagent.app.compiler.adb.AdbResult) {
    Card(shape = RoundedCornerShape(6.dp), colors = CardDefaults.cardColors(containerColor = if (result.success) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f))) {
        Column(Modifier.padding(10.dp)) {
            Row {
                Text("$ ${result.command}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                Text("${result.durationMs}ms", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
            }
            if (result.stdout.isNotEmpty()) Text(result.stdout, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            if (result.stderr.isNotEmpty()) Text(result.stderr, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun ScriptHistoryTab(scripts: List<com.superagent.app.compiler.script.GeneratedScript>, viewModel: CompilerViewModel) {
    if (scripts.isEmpty()) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No scripts generated yet.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)) }; return }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(scripts) { script ->
            Card(shape = RoundedCornerShape(10.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(script.config.projectName, fontWeight = FontWeight.Bold)
                    Text(script.config.packageName, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Text(script.scriptPath.substringAfterLast("/"), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { viewModel.shareScript(script) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Icon(Icons.Filled.Share, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("Share", fontSize = 12.sp) }
                        OutlinedButton(onClick = { viewModel.uploadToDrive(script) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Icon(Icons.Filled.CloudUpload, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("Drive", fontSize = 12.sp) }
                        OutlinedButton(onClick = { viewModel.deleteScript(script) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Icon(Icons.Filled.Delete, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error); Spacer(Modifier.width(4.dp)); Text("Delete", fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
}
