package com.superagent.app.agent.state

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import java.util.LinkedList
import java.util.UUID

// ─── State definitions ────────────────────────────────────────────────────────

sealed class AgentState {
    object Idle : AgentState()
    data class Processing(val directive: String, val step: Int = 0) : AgentState()
    data class Building(val target: String, val progress: Int = 0) : AgentState()
    data class Executing(val command: String) : AgentState()
    data class Completed(val result: DirectiveResult) : AgentState()
    data class Error(val message: String, val recoverable: Boolean = true) : AgentState()
    object Paused : AgentState()
}

data class DirectiveResult(
    val id: String = UUID.randomUUID().toString(),
    val directive: String,
    val output: String,
    val success: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L,
    val artifacts: List<String> = emptyList()
)

// ─── Context window entry ─────────────────────────────────────────────────────

data class ContextEntry(
    val role: String,       // "user" | "agent" | "system" | "result"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tokenEstimate: Int = (content.length / 4).coerceAtLeast(1)
)

// ─── Sliding-window context buffer ───────────────────────────────────────────

class ContextWindowBuffer(
    private val maxTokens: Int = 131_072,        // 128k token equivalent cap
    private val pruneToFraction: Float = 0.70f   // prune to 70% when full
) {
    private val _entries: LinkedList<ContextEntry> = LinkedList()
    private var _totalTokens: Int = 0

    val entries: List<ContextEntry> get() = _entries.toList()
    val totalTokens: Int get() = _totalTokens
    val size: Int get() = _entries.size

    fun push(entry: ContextEntry) {
        _entries.addLast(entry)
        _totalTokens += entry.tokenEstimate
        if (_totalTokens > maxTokens) prune()
    }

    private fun prune() {
        val target = (maxTokens * pruneToFraction).toInt()
        while (_totalTokens > target && _entries.isNotEmpty()) {
            val removed = _entries.removeFirst()
            _totalTokens -= removed.tokenEstimate
        }
        Timber.d("Context pruned → ${_entries.size} entries, ~$_totalTokens tokens")
    }

    fun buildContextBlock(systemInstructions: String, safetyLevel: Float): String = buildString {
        appendLine("=== SYSTEM ===")
        appendLine(systemInstructions.ifBlank { "General-purpose superagent. Process all directives." })
        appendLine("[SAFETY_LEVEL: $safetyLevel | ${safetyLevelLabel(safetyLevel)}]")
        appendLine()
        appendLine("=== CONTEXT (${_entries.size} entries, ~$_totalTokens tokens) ===")
        _entries.forEach { e -> appendLine("[${e.role.uppercase()}] ${e.content}") }
    }

    fun clear() { _entries.clear(); _totalTokens = 0 }

    private fun safetyLevelLabel(v: Float) = when {
        v < 0.2f -> "UNRESTRICTED"
        v < 0.4f -> "LOW"
        v < 0.6f -> "MEDIUM"
        v < 0.8f -> "HIGH"
        else -> "MAXIMUM"
    }
}

// ─── State machine engine ────────────────────────────────────────────────────

class AgentStateMachine(
    private val agentId: String,
    private val systemInstructions: String,
    initialSafetyLevel: Float = 0.7f
) {
    private val _state = MutableStateFlow<AgentState>(AgentState.Idle)
    val state: StateFlow<AgentState> = _state.asStateFlow()

    private val _resultLog = MutableStateFlow<List<DirectiveResult>>(emptyList())
    val resultLog: StateFlow<List<DirectiveResult>> = _resultLog.asStateFlow()

    var safetyLevel: Float = initialSafetyLevel
        private set

    val contextWindow = ContextWindowBuffer()

    // ── Directive patterns ────────────────────────────────────────────────────

    private val buildPattern = Regex("""(?i)\b(build|compile|generate|create|make|output)\b.{0,30}?\b(apk|script|project|app|module)\b""")
    private val adbPattern   = Regex("""(?i)\b(adb|install|push|pull|shell|connect)\b\s+(.+)""")
    private val memoryPattern = Regex("""(?i)\b(remember|store|save|recall|forget|retrieve)\b\s*(.*)""")
    private val statusPattern = Regex("""(?i)\b(status|state|report|summary|log|info)\b""")
    private val helpPattern  = Regex("""(?i)\b(help|what can|commands|usage)\b""")
    private val safetyPattern = Regex("""(?i)\bset\s+safety\s+(\d+\.?\d*)\b""")
    private val clearPattern  = Regex("""(?i)\b(clear|reset|wipe)\b""")

    // ── Public API ────────────────────────────────────────────────────────────

    suspend fun processDirective(raw: String): DirectiveResult {
        val directive = if (safetyLevel > 0.65f) sanitize(raw) else raw.trim()
        val start = System.currentTimeMillis()
        _state.value = AgentState.Processing(directive)
        contextWindow.push(ContextEntry("user", directive))

        Timber.d("[$agentId] Directive: \"$directive\" | safety=$safetyLevel")

        val result: DirectiveResult = when {
            buildPattern.containsMatchIn(directive)  -> handleBuild(directive)
            adbPattern.containsMatchIn(directive)    -> handleAdb(directive)
            safetyPattern.containsMatchIn(directive) -> handleSetSafety(directive)
            memoryPattern.containsMatchIn(directive) -> handleMemory(directive)
            statusPattern.containsMatchIn(directive) -> handleStatus()
            helpPattern.containsMatchIn(directive)   -> handleHelp()
            clearPattern.containsMatchIn(directive)  -> handleClear()
            else -> handleGeneric(directive)
        }

        val finalResult = result.copy(durationMs = System.currentTimeMillis() - start)
        contextWindow.push(ContextEntry("result", finalResult.output.take(512)))
        _resultLog.value = (_resultLog.value + finalResult).takeLast(500)
        _state.value = AgentState.Completed(finalResult)
        return finalResult
    }

    // ── Handlers ──────────────────────────────────────────────────────────────

    private fun handleBuild(directive: String): DirectiveResult {
        _state.value = AgentState.Building(directive)
        return DirectiveResult(
            directive = directive,
            output = "BUILD directive queued → CompilerOrchestrator.\n" +
                    "Navigate to the Compiler tab, fill in your project details,\n" +
                    "then tap 'Generate Build Script' to produce a runnable .sh file.",
            success = true,
            artifacts = listOf("→ Compiler tab")
        )
    }

    private fun handleAdb(directive: String): DirectiveResult {
        val match = adbPattern.find(directive)
        val command = match?.groupValues?.getOrNull(2)?.trim() ?: directive
        _state.value = AgentState.Executing(command)
        return DirectiveResult(
            directive = directive,
            output = "ADB command queued: \"$command\"\nNavigate to Compiler → ADB Console to execute and view output.",
            success = true
        )
    }

    private fun handleSetSafety(directive: String): DirectiveResult {
        val match = safetyPattern.find(directive)
        val value = match?.groupValues?.get(1)?.toFloatOrNull()
        return if (value != null) {
            val normalized = (value / if (value > 1f) 100f else 1f).coerceIn(0f, 1f)
            setSafetyLevel(normalized)
            DirectiveResult(directive = directive, output = "Safety level set to ${(normalized * 100).toInt()}% — ${safetyLevelLabel(normalized)}", success = true)
        } else {
            DirectiveResult(directive = directive, output = "Usage: set safety <0.0–1.0> or <0–100>", success = false)
        }
    }

    private fun handleMemory(directive: String): DirectiveResult {
        val match = memoryPattern.find(directive)
        val verb = match?.groupValues?.getOrNull(1)?.lowercase() ?: ""
        val content = match?.groupValues?.getOrNull(2)?.trim() ?: ""
        return when (verb) {
            "forget", "wipe" -> {
                contextWindow.clear()
                DirectiveResult(directive = directive, output = "Context window cleared. Starting fresh.", success = true)
            }
            "recall", "retrieve" -> {
                val info = "Context: ${contextWindow.size} entries | ~${contextWindow.totalTokens} tokens\n" +
                        contextWindow.entries.takeLast(5).joinToString("\n") { "[${it.role}] ${it.content.take(60)}" }
                DirectiveResult(directive = directive, output = info, success = true)
            }
            else -> {
                if (content.isNotEmpty()) {
                    contextWindow.push(ContextEntry("system", "[STORED] $content"))
                    DirectiveResult(directive = directive, output = "Stored in context: \"$content\"", success = true)
                } else {
                    DirectiveResult(directive = directive, output = "Nothing to store.", success = false)
                }
            }
        }
    }

    private fun handleStatus(): DirectiveResult {
        val log = _resultLog.value
        val output = buildString {
            appendLine("Agent ID   : $agentId")
            appendLine("State      : ${_state.value::class.simpleName}")
            appendLine("Safety     : ${(safetyLevel * 100).toInt()}% — ${safetyLevelLabel(safetyLevel)}")
            appendLine("Directives : ${log.size}")
            appendLine("Context    : ${contextWindow.size} entries | ~${contextWindow.totalTokens} tokens")
            if (log.isNotEmpty()) {
                appendLine("Last       : ${log.last().directive.take(60)}")
                appendLine("Last out   : ${log.last().output.take(80)}")
            }
        }
        return DirectiveResult(directive = "status", output = output, success = true)
    }

    private fun handleHelp(): DirectiveResult {
        val help = """
Available directives:
  build <apk|script|module>  → Queue a compilation task
  adb <command>              → Queue an ADB command
  remember <text>            → Store info in context
  recall                     → Show recent context entries
  forget                     → Clear the context window
  status                     → Show agent status report
  set safety <0.0–1.0>       → Adjust safety constraints
  clear                      → Clear context window
  help                       → Show this message
        """.trimIndent()
        return DirectiveResult(directive = "help", output = help, success = true)
    }

    private fun handleClear(): DirectiveResult {
        contextWindow.clear()
        return DirectiveResult(directive = "clear", output = "Context window cleared.", success = true)
    }

    private fun handleGeneric(directive: String): DirectiveResult {
        return DirectiveResult(
            directive = directive,
            output = "Directive received and logged to context.\nNo specific handler matched. Type 'help' for available commands.",
            success = true
        )
    }

    // ── Safety ────────────────────────────────────────────────────────────────

    fun setSafetyLevel(level: Float) {
        safetyLevel = level.coerceIn(0f, 1f)
        Timber.d("[$agentId] Safety → $safetyLevel")
    }

    private fun sanitize(input: String): String = input
        .replace(Regex("""[<>"';`]"""), "")
        .replace(Regex("""(?i)(rm\s+-rf|chmod\s+777|sudo\s+rm|/etc/shadow|/proc/self/mem)"""), "[BLOCKED]")
        .trim()
        .take(8192)

    private fun safetyLevelLabel(v: Float) = when {
        v < 0.2f -> "UNRESTRICTED"
        v < 0.4f -> "LOW"
        v < 0.6f -> "MEDIUM"
        v < 0.8f -> "HIGH"
        else -> "MAXIMUM"
    }

    // ── Control ───────────────────────────────────────────────────────────────

    fun pause() { _state.value = AgentState.Paused }
    fun resume() { if (_state.value is AgentState.Paused) _state.value = AgentState.Idle }
    fun reset() { _state.value = AgentState.Idle; contextWindow.clear() }
}
