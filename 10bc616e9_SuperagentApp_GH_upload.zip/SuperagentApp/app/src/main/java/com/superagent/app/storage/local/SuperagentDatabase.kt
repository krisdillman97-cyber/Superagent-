package com.superagent.app.storage.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.superagent.app.agent.profile.AgentProfile
import com.superagent.app.agent.profile.AgentProfileDao

@Database(
    entities = [AgentProfile::class],
    version = 1,
    exportSchema = false
)
abstract class SuperagentDatabase : RoomDatabase() {
    abstract fun agentProfileDao(): AgentProfileDao
}
