package com.superagent.app.compiler.adb

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader

data class AdbResult(
    val command: String,
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val success: Boolean = exitCode == 0,
    val durationMs: Long = 0L
)

class AdbOrchestrator {

    private var connectedDevice: String? = null

    /** Check if ADB binary is available in PATH */
    suspend fun isAdbAvailable(): Boolean = withContext(Dispatchers.IO) {
        try {
            val result = exec(listOf("adb", "version"))
            result.success
        } catch (e: Exception) {
            false
        }
    }

    /** List all connected devices */
    suspend fun listDevices(): AdbResult = withContext(Dispatchers.IO) {
        exec(listOf("adb", "devices", "-l"))
    }

    /** Connect to a device over TCP/IP (Wi-Fi ADB) */
    suspend fun connectWifi(host: String, port: Int = 5555): AdbResult = withContext(Dispatchers.IO) {
        val result = exec(listOf("adb", "connect", "$host:$port"))
        if (result.success) connectedDevice = "$host:$port"
        result
    }

    /** Disconnect all or a specific device */
    suspend fun disconnect(target: String? = null): AdbResult = withContext(Dispatchers.IO) {
        val args = if (target != null) listOf("adb", "disconnect", target) else listOf("adb", "disconnect")
        exec(args).also { if (it.success) connectedDevice = null }
    }

    /** Install an APK on the connected device */
    suspend fun installApk(apkPath: String, reinstall: Boolean = true): AdbResult = withContext(Dispatchers.IO) {
        val args = mutableListOf("adb").apply {
            connectedDevice?.let { addAll(listOf("-s", it)) }
            add("install")
            if (reinstall) add("-r")
            add(apkPath)
        }
        exec(args)
    }

    /** Push a file to the device */
    suspend fun pushFile(localPath: String, remotePath: String): AdbResult = withContext(Dispatchers.IO) {
        exec(buildArgs("push", localPath, remotePath))
    }

    /** Pull a file from the device */
    suspend fun pullFile(remotePath: String, localPath: String): AdbResult = withContext(Dispatchers.IO) {
        exec(buildArgs("pull", remotePath, localPath))
    }

    /** Run an ADB shell command */
    suspend fun shell(command: String): AdbResult = withContext(Dispatchers.IO) {
        exec(buildArgs("shell", command))
    }

    /** Get device properties */
    suspend fun getDeviceInfo(): AdbResult = withContext(Dispatchers.IO) {
        shell("getprop ro.product.model && getprop ro.build.version.release && getprop ro.build.version.sdk")
    }

    /** Reboot the device */
    suspend fun reboot(mode: RebootMode = RebootMode.NORMAL): AdbResult = withContext(Dispatchers.IO) {
        when (mode) {
            RebootMode.NORMAL -> exec(buildArgs("reboot"))
            RebootMode.RECOVERY -> exec(buildArgs("reboot", "recovery"))
            RebootMode.BOOTLOADER -> exec(buildArgs("reboot", "bootloader"))
        }
    }

    /** Execute a raw ADB command string — used from agent directives */
    suspend fun executeRaw(rawCommand: String): AdbResult = withContext(Dispatchers.IO) {
        val trimmed = rawCommand.trim()
        val parts = trimmed.split(Regex("\\s+"))
        val fullArgs = if (parts.firstOrNull() == "adb") parts else listOf("adb") + parts
        exec(fullArgs)
    }

    // ── Internal execution engine ────────────────────────────────────────────

    private fun buildArgs(vararg args: String): List<String> {
        val base = mutableListOf("adb")
        connectedDevice?.let { base.addAll(listOf("-s", it)) }
        base.addAll(args)
        return base
    }

    private fun exec(args: List<String>): AdbResult {
        val start = System.currentTimeMillis()
        Timber.d("ADB exec: ${args.joinToString(" ")}")
        return try {
            val process = ProcessBuilder(args)
                .redirectErrorStream(false)
                .start()

            val stdout = process.inputStream.bufferedReader().readText()
            val stderr = process.errorStream.bufferedReader().readText()
            val exitCode = process.waitFor()

            AdbResult(
                command = args.joinToString(" "),
                exitCode = exitCode,
                stdout = stdout.trim(),
                stderr = stderr.trim(),
                durationMs = System.currentTimeMillis() - start
            )
        } catch (e: Exception) {
            Timber.e(e, "ADB exec failed: ${args.joinToString(" ")}")
            AdbResult(
                command = args.joinToString(" "),
                exitCode = -1,
                stdout = "",
                stderr = e.message ?: "Unknown error — is ADB in PATH?",
                durationMs = System.currentTimeMillis() - start
            )
        }
    }

    enum class RebootMode { NORMAL, RECOVERY, BOOTLOADER }
}
