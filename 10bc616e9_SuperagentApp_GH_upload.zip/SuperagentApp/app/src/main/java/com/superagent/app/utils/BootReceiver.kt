package com.superagent.app.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import com.superagent.app.ui.overlay.FloatingHudService
import timber.log.Timber

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON") return

        Timber.d("BootReceiver: boot completed")

        val prefs: SharedPreferences =
            context.getSharedPreferences("superagent_prefs", Context.MODE_PRIVATE)
        val autoRestart = prefs.getBoolean("hud_auto_restart", false)

        if (autoRestart) {
            val serviceIntent = Intent(context, FloatingHudService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            Timber.i("HUD auto-restarted after boot")
        }
    }
}
