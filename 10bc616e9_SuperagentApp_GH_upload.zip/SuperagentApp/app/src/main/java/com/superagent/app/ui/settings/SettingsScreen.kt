package com.superagent.app.ui.settings

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.superagent.app.ui.theme.COLOR_PRESETS
import com.superagent.app.ui.theme.ThemeConfig
import com.superagent.app.ui.theme.ThemeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(themeViewModel: ThemeViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val themeConfig by themeViewModel.themeConfig.collectAsState()
    val prefs = remember { context.getSharedPreferences("superagent_prefs", Context.MODE_PRIVATE) }
    var hudAutoRestart by remember { mutableStateOf(prefs.getBoolean("hud_auto_restart", false)) }

    // Android 13 notification permission
    val hasNotifPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    } else true

    val notifPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* result handled by recompose */ }

    // Overlay permission
    val canDrawOverlay = Settings.canDrawOverlays(context)

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Settings", fontWeight = FontWeight.Bold) })
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {

            // ── PERMISSIONS SECTION ────────────────────────────────────────
            SettingsSection("Permissions") {
                // Overlay permission
                PermissionRow(
                    label = "Draw Over Other Apps",
                    subtitle = "Required for Floating HUD",
                    granted = canDrawOverlay,
                    onRequest = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    }
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                // Notification permission (Android 13+)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    PermissionRow(
                        label = "Notifications",
                        subtitle = "Required to show HUD foreground notification",
                        granted = hasNotifPerm,
                        onRequest = {
                            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    )
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                }

                // Install packages
                val canInstall = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.packageManager.canRequestPackageInstalls()
                } else true

                PermissionRow(
                    label = "Install Packages",
                    subtitle = "Required to sideload compiled APKs",
                    granted = canInstall,
                    onRequest = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startActivity(
                                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:${context.packageName}"))
                            )
                        }
                    }
                )
            }

            // ── HUD SECTION ───────────────────────────────────────────────
            SettingsSection("Floating HUD") {
                SettingsToggleRow(
                    label = "Auto-restart HUD on Boot",
                    subtitle = "Restart floating overlay after device reboots",
                    checked = hudAutoRestart,
                    onToggle = {
                        hudAutoRestart = it
                        prefs.edit().putBoolean("hud_auto_restart", it).apply()
                    }
                )
            }

            // ── THEME SECTION ─────────────────────────────────────────────
            SettingsSection("Appearance") {
                // Dark mode toggle
                SettingsToggleRow(
                    label = "Dark Mode",
                    subtitle = "Switch between dark and light theme",
                    checked = themeConfig.isDarkMode,
                    onToggle = { themeViewModel.toggleDark() }
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                // Color presets
                Text(
                    "Color Theme",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                ColorPresetGrid(
                    currentPrimary = themeConfig.primaryColorArgb,
                    onSelect = { preset ->
                        themeViewModel.updateConfig(
                            themeConfig.copy(
                                primaryColorArgb = preset.primary,
                                secondaryColorArgb = preset.secondary
                            )
                        )
                    }
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                // Density slider
                SliderRow(
                    label = "UI Density",
                    value = themeConfig.density,
                    valueRange = 0.8f..1.2f,
                    steps = 3,
                    displayValue = { "${(it * 100).toInt()}%" },
                    onValueChange = { themeViewModel.setDensity(it) }
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                // Font scale
                SliderRow(
                    label = "Font Scale",
                    value = themeConfig.fontScale,
                    valueRange = 0.8f..1.4f,
                    steps = 5,
                    displayValue = { "${(it * 100).toInt()}%" },
                    onValueChange = { themeViewModel.setFontScale(it) }
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                // Corner radius
                SliderRow(
                    label = "Corner Radius",
                    value = themeConfig.cornerRadius,
                    valueRange = 0f..28f,
                    steps = 13,
                    displayValue = { "${it.toInt()}dp" },
                    onValueChange = { themeViewModel.setCornerRadius(it) }
                )
            }

            // ── ABOUT SECTION ─────────────────────────────────────────────
            SettingsSection("About") {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Superagent", fontWeight = FontWeight.Bold)
                        Text("Version 1.0.0-debug", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Text("Target SDK: Android 13 (API 33)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Text("Build engine: AAPT2 + D8", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                    Icon(Icons.Filled.SmartToy, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            title.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(shape = RoundedCornerShape(12.dp)) {
            Column { content() }
        }
    }
}

@Composable
fun PermissionRow(label: String, subtitle: String, granted: Boolean, onRequest: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
        if (granted) {
            Icon(Icons.Filled.CheckCircle, "Granted", tint = Color(0xFF4CAF50), modifier = Modifier.size(24.dp))
        } else {
            OutlinedButton(onClick = onRequest, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                Text("Grant", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SettingsToggleRow(label: String, subtitle: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    displayValue: (Float) -> String,
    onValueChange: (Float) -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(displayValue(value), fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = valueRange, steps = steps)
    }
}

@Composable
fun ColorPresetGrid(currentPrimary: Long, onSelect: (com.superagent.app.ui.theme.ColorPreset) -> Unit) {
    val presets = com.superagent.app.ui.theme.COLOR_PRESETS
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        presets.take(4).forEach { preset ->
            val isSelected = preset.primary == currentPrimary
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(preset.primary))
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) Color.White else Color.Transparent,
                        shape = CircleShape
                    )
                    .clickable { onSelect(preset) }
            ) {
                if (isSelected) {
                    Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(18.dp))
                }
            }
        }
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        presets.drop(4).forEach { preset ->
            val isSelected = preset.primary == currentPrimary
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(preset.primary))
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) Color.White else Color.Transparent,
                        shape = CircleShape
                    )
                    .clickable { onSelect(preset) }
            ) {
                if (isSelected) {
                    Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(18.dp))
                }
            }
        }
    }
}
