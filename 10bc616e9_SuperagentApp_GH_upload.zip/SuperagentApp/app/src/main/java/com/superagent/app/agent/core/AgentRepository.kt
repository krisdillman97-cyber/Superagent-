package com.superagent.app.agent.core

import com.superagent.app.agent.profile.AgentProfile
import com.superagent.app.agent.profile.AgentProfileDao
import com.superagent.app.agent.state.AgentStateMachine
import com.superagent.app.agent.state.DirectiveResult
import kotlinx.coroutines.flow.Flow
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentRepository @Inject constructor(
    private val dao: AgentProfileDao
) {
    /** In-memory map of running state machines keyed by profile ID */
    private val machines: MutableMap<String, AgentStateMachine> = mutableMapOf()

    val allProfiles: Flow<List<AgentProfile>> = dao.getAllProfiles()
    val activeProfile: Flow<AgentProfile?> = dao.getActiveProfile()

    suspend fun createProfile(profile: AgentProfile) {
        dao.insertProfile(profile)
        Timber.d("Profile created: ${profile.id} — ${profile.name}")
    }

    suspend fun updateProfile(profile: AgentProfile) {
        dao.updateProfile(profile.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteProfile(profile: AgentProfile) {
        machines.remove(profile.id)
        dao.deleteProfile(profile)
    }

    suspend fun cloneProfile(profile: AgentProfile): AgentProfile {
        val clone = profile.copy(
            id = java.util.UUID.randomUUID().toString(),
            name = "${profile.name} (Clone)",
            isActive = false,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        dao.insertProfile(clone)
        return clone
    }

    suspend fun activateProfile(id: String) {
        dao.deactivateAll()
        dao.activateProfile(id)
    }

    /** Deactivate all agents without activating any */
    suspend fun deactivateAll() {
        dao.deactivateAll()
    }

    fun getOrCreateMachine(profile: AgentProfile): AgentStateMachine {
        return machines.getOrPut(profile.id) {
            AgentStateMachine(
                agentId = profile.id,
                systemInstructions = profile.systemInstructions,
                initialSafetyLevel = profile.safetyLevel
            )
        }
    }

    suspend fun sendDirective(profileId: String, directive: String): DirectiveResult? {
        val profile = dao.getProfileById(profileId) ?: return null
        val machine = getOrCreateMachine(profile)
        machine.setSafetyLevel(profile.safetyLevel)
        val result = machine.processDirective(directive)
        dao.incrementDirectiveCount(profileId)
        return result
    }

    fun getMachine(profileId: String): AgentStateMachine? = machines[profileId]
}
