package com.superagent.app.ui.storage

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.superagent.app.compiler.builder.CompilerOrchestrator
import com.superagent.app.storage.drive.DriveRepository
import com.superagent.app.storage.drive.DriveStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

@HiltViewModel
class StorageViewModel @Inject constructor(
    private val driveRepo: DriveRepository,
    private val compilerOrchestrator: CompilerOrchestrator,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val driveStatus: StateFlow<DriveStatus> = driveRepo.status
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DriveStatus.SignedOut)

    private val _driveFiles = MutableStateFlow<List<com.google.api.services.drive.model.File>>(emptyList())
    val driveFiles: StateFlow<List<com.google.api.services.drive.model.File>> = _driveFiles.asStateFlow()

    private val _localScripts = MutableStateFlow<List<File>>(emptyList())
    val localScripts: StateFlow<List<File>> = _localScripts.asStateFlow()

    init {
        refreshLocalScripts()
    }

    fun checkExistingSignIn() {
        driveRepo.checkExistingSignIn()
        if (driveRepo.status.value is DriveStatus.SignedIn) {
            refreshDriveFiles()
        }
    }

    fun getSignInIntent(): Intent = driveRepo.getSignInIntent()

    fun handleSignIn(account: GoogleSignInAccount) {
        driveRepo.handleSignInResult(account)
        refreshDriveFiles()
    }

    fun signOut() = driveRepo.signOut()

    fun uploadFile(file: File) = viewModelScope.launch {
        val mimeType = when (file.extension.lowercase()) {
            "sh" -> "text/x-sh"
            "apk" -> "application/vnd.android.package-archive"
            "json" -> "application/json"
            "zip" -> "application/zip"
            else -> "application/octet-stream"
        }
        driveRepo.uploadFile(file, mimeType)
        refreshDriveFiles()
    }

    fun refreshLocalScripts() {
        _localScripts.value = compilerOrchestrator.listGeneratedScripts()
    }

    fun refreshDriveFiles() = viewModelScope.launch {
        try {
            _driveFiles.value = driveRepo.listSuperagentFiles()
        } catch (e: Exception) {
            Timber.e(e, "Failed to refresh Drive files")
        }
    }
}
