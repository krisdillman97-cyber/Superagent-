package com.superagent.app.storage.drive

import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.api.client.http.FileContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

sealed class DriveStatus {
    object SignedOut : DriveStatus()
    data class SignedIn(val email: String) : DriveStatus()
    data class Uploading(val fileName: String) : DriveStatus()
    data class Uploaded(val fileId: String, val fileName: String, val webLink: String) : DriveStatus()
    data class Error(val message: String) : DriveStatus()
}

class DriveRepository(private val context: Context) {

    private val _status = MutableStateFlow<DriveStatus>(DriveStatus.SignedOut)
    val status: StateFlow<DriveStatus> = _status.asStateFlow()

    private var driveService: Drive? = null
    private var folderId: String? = null

    private val FOLDER_NAME = "Superagent Exports"

    val signInClient: GoogleSignInClient by lazy {
        GoogleSignIn.getClient(
            context,
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(Scope(DriveScopes.DRIVE_FILE))
                .build()
        )
    }

    fun getSignInIntent(): Intent = signInClient.signInIntent

    fun handleSignInResult(account: GoogleSignInAccount) {
        val credential = GoogleAccountCredential
            .usingOAuth2(context, listOf(DriveScopes.DRIVE_FILE))
            .apply { selectedAccount = account.account }

        driveService = Drive.Builder(
            AndroidHttp.newCompatibleTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("Superagent").build()

        _status.value = DriveStatus.SignedIn(account.email ?: "Unknown")
        Timber.i("Drive signed in: ${account.email}")
    }

    fun checkExistingSignIn() {
        val account = GoogleSignIn.getLastSignedInAccount(context) ?: return
        if (GoogleSignIn.hasPermissions(account, Scope(DriveScopes.DRIVE_FILE))) {
            handleSignInResult(account)
        }
    }

    fun signOut() {
        signInClient.signOut()
        driveService = null
        folderId = null
        _status.value = DriveStatus.SignedOut
    }

    suspend fun uploadFile(localFile: File, mimeType: String = "application/octet-stream"): String? =
        withContext(Dispatchers.IO) {
            val service = driveService ?: run {
                _status.value = DriveStatus.Error("Not signed in to Google Drive")
                return@withContext null
            }
            try {
                _status.value = DriveStatus.Uploading(localFile.name)
                val parentId = getOrCreateFolder(service)
                val meta = DriveFile().apply {
                    name = localFile.name
                    parents = listOf(parentId)
                }
                val content = FileContent(mimeType, localFile)
                val file = service.files().create(meta, content)
                    .setFields("id,webViewLink")
                    .execute()
                val link = file.webViewLink ?: "https://drive.google.com/file/d/${file.id}"
                _status.value = DriveStatus.Uploaded(file.id, localFile.name, link)
                Timber.i("Uploaded: ${localFile.name} → ${file.id}")
                file.id
            } catch (e: Exception) {
                _status.value = DriveStatus.Error("Upload failed: ${e.message}")
                Timber.e(e, "Drive upload error")
                null
            }
        }

    suspend fun listSuperagentFiles(): List<DriveFile> = withContext(Dispatchers.IO) {
        val service = driveService ?: return@withContext emptyList()
        try {
            val folder = getOrCreateFolder(service)
            service.files().list()
                .setQ("'$folder' in parents and trashed=false")
                .setFields("files(id,name,mimeType,size,createdTime,webViewLink)")
                .execute()
                .files ?: emptyList()
        } catch (e: Exception) {
            Timber.e(e, "List Drive files failed")
            emptyList()
        }
    }

    private suspend fun getOrCreateFolder(service: Drive): String = withContext(Dispatchers.IO) {
        folderId?.let { return@withContext it }
        val q = "mimeType='application/vnd.google-apps.folder' and name='$FOLDER_NAME' and trashed=false"
        val existing = service.files().list().setQ(q).setFields("files(id)").execute().files.firstOrNull()
        if (existing != null) {
            folderId = existing.id
            return@withContext existing.id
        }
        val meta = DriveFile().apply {
            name = FOLDER_NAME
            mimeType = "application/vnd.google-apps.folder"
        }
        val created = service.files().create(meta).setFields("id").execute()
        folderId = created.id
        created.id
    }
}
