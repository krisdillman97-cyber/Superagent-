# Superagent Android App — Build Instructions

## Requirements
- Android Studio Ladybug (2024.2.1) or newer
- Android SDK 33 (Android 13), JDK 17, Kotlin 2.0.21

## Quick Start (Android Studio)
1. Unzip SuperagentApp_Android13_v1.0.zip
2. Open Android Studio > Open > select the SuperagentApp/ folder
3. Wait for Gradle sync (needs internet for first sync)
4. Connect device or emulator (API 29-33)
5. Click Run — Studio builds and installs the debug APK

## Manual Build (CLI)
  cd SuperagentApp
  chmod +x gradlew
  ./gradlew assembleDebug
Output: app/build/outputs/apk/debug/app-debug.apk
Install: adb install -r app/build/outputs/apk/debug/app-debug.apk

## Versions
Target SDK: Android 13 (API 33) | Min SDK: Android 10 (API 29)
Kotlin 2.0.21 | Compose BOM 2024.09.03 | Hilt 2.52 | Room 2.6.1 | AGP 8.5.2

## First Run Setup
1. Floating HUD: Settings > grant Draw Over Other Apps > enable on Dashboard
2. Notifications: granted automatically on first launch (Android 13)
3. Google Drive: Storage tab > Connect Drive > sign in
4. Build Scripts: Compiler tab > fill details > Generate Build Script
